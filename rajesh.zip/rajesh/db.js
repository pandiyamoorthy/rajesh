document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Clear previous error messages
    document.getElementById('error-message').innerText = '';

    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const description = document.getElementById('description').value.trim();
    const image = document.getElementById('image').files[0];

    // Validate form fields
    if (!name || !email || !description || !image) {
        document.getElementById('error-message').innerText = 'All fields are required.';
        return;
    }

    // Simple email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        document.getElementById('error-message').innerText = 'Please enter a valid email address.';
        return;
    }

    // If validation passes, you can submit the form or perform further actions
    alert('Form submitted successfully!');
    // Here you can add code to actually submit the form data to a server if needed
});